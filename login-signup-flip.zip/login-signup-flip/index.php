
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>login</title>

    <!-- Bootstrap core CSS -->
    <link href="build/css/bootstrap.min.css" rel="stylesheet">
    <link href="build/css/font-awesome.min.css" rel="stylesheet">
    <link href="build/css/style.css" rel="stylesheet">

    <!--google fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans+Condensed:300" rel="stylesheet">
    
  </head>

  <body>

    <div class="container">

      <div class="row">

        <div class="col-md-4"></div>
        <div class="col-md-4">



          <div class="flip">
        <div class="card"> 
          <div class="face front"> 
              


            <div class="panel panel-default">

              <form class="form-horizontal">
                
                <br>

                <h1 class="text-center">LOGO</h1>

                <br>
                
                <input class="form-control" placeholder="Username"/>
                <input class="form-control" placeholder="Password"/>
                <p class="text-right"><a href="">Forgot Password</a></p>
                <button class="btn btn-primary btn-block">LOG IN</button>

                <p class="blue">Sign in with</p>

                <hr>
                <p class="text-center">
                  <a href="#" class="fliper-btn">Register Your Membership</a>
                </p>
              </form>

            </div>


          </div> 
          <div class="face back"> 
            

              <div class="panel panel-default">

              <form class="form-horizontal" method="post" action="">
                
                <br>

                <h1 class="text-center">LOGO</h1>

                <br>
                <label>Basic Information</label>
                <input class="form-control" placeholder="Fullname"/>
                <input class="form-control" placeholder="Phone Number"/>
                <label>list your 3 choice of group</label>
                <select class="form-control">
                	<option>Select a Group</option>
                	<option>21st Century Daniel</option>
                	<option>Bezalels Purple Linen</option>
                	<option>Book Worm</option>
                	<option>Biggest Looser</option>
                	<option>Bumps & Grace</option>
                	<option>Butter & Love</option>
                	<option>Chewing the cord</option>
                	<option>Controller Hand</option>
                	<option>Curls & Extensions</option>
                	<option>David-Like</option>
                </select>
                <select class="form-control">
                	<option>Select a group</option>
                	<option>21st Century Daniel</option>
                	<option>Bezalels Purple Linen</option>
                	<option>Book Worm</option>
                	<option>Biggest Looser</option>
                	<option>Bumps & Grace</option>
                	<option>Butter & Love</option>
                	<option>Chewing the cord</option>
                	<option>Controller Hand</option>
                	<option>Curls & Extensions</option>
                	<option>David-Like</option>
                </select>
                <select class="form-control">
                	<option>Select a group</option>
                	<option>21st Century Daniel</option>
                	<option>Bezalels Purple Linen</option>
                	<option>Book Worm</option>
                	<option>Biggest Looser</option>
                	<option>Bumps & Grace</option>
                	<option>Butter & Love</option>
                	<option>Chewing the cord</option>
                	<option>Controller Hand</option>
                	<option>Curls & Extensions</option>
                	<option>David-Like</option>
                </select>
                <fieldset>
  				<legend class="reduce">Pick two days you would prefer to attend group meetings (meetings will be held for evenings)</legend>
    				<input type="checkbox" id="coding" name="interest" value="coding">
    				<label for="monday">Mondays</label>

    				<input type="checkbox" id="music" name="interest" value="music">
    				<label for="wednesday">Wednesdays</label>

    				<input type="checkbox" id="music" name="interest" value="music">
    				<label for="friday">Fridays</label>

    				<input type="checkbox" id="music" name="interest" value="music">
    				<label for="saturdays">Saturdays</label>

    				<input type="checkbox" id="music" name="interest" value="music">
    				<label for="sundays">Sundays</label>
				</fieldset>
                <button class="btn btn-primary btn-block">SUBMIT</button>


                <p class="text-center">
                  <a href="#" class="fliper-btn">Already have an account?</a>
                </p>
                
              </form>

            </div>




          </div>
        </div>   
      </div>




        </div>
        <div class="col-md-4"></div>

      </div>

    </div><!-- /.container -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="build/js/jquery.min.js"></script>
    <script src="build/js/bootstrap.min.js"></script>
    <script>

    $('.fliper-btn').click(function(){
    $('.flip').find('.card').toggleClass('flipped');

});
    </script>
  </body>
</html>




      